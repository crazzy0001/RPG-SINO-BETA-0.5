/* Itens. t: w=arma a=armadura s=escudo c=consumível f=alimento i=ingrediente. r=raridade (0 Comum..5 Mítico). */
RPG.Rar=["Comum","Incomum","Raro","Épico","Lendário","Mítico"];
(function(){
const W=(n,a,b,s,x)=>Object.assign({n,t:"w",d:[a,b],s,r:0},x),A=(n,p)=>({n,t:"a",p,r:0}),C=(n,e,d)=>({n,t:"c",e,d,r:0}),F=(n,f,x)=>Object.assign({n,t:"f",e:{fome:f},d:"Recupera "+f+" de fome.",r:0},x),I=n=>({n,t:"i",d:"Ingrediente.",r:0});
RPG.Items={
espada:W("Espada simples",8,12,"for"),machado:W("Machado de batalha",10,14,"for"),adaga:W("Adaga",5,8,"agi"),
arco:W("Arco curto",7,10,"agi"),besta:W("Besta leve",9,13,"agi"),lanca:W("Lança",8,11,"for"),
cajado:W("Cajado arcano",5,8,"int"),maca:W("Maça",9,12,"for"),foice:W("Foice",8,12,"for"),manoplas:W("Manoplas",6,9,"agi"),
roupa:A("Roupa comum",0),couro:A("Armadura de couro",3),reforcada:A("Armadura reforçada",5),malha:A("Cota de malha",7),pesada:A("Armadura pesada",10),
escudo_p:{n:"Escudo pequeno",t:"s",p:3,r:0},escudo_r:{n:"Escudo reforçado",t:"s",p:5,r:1},
cura_menor:C("Poção de Cura Menor",{pv:10},"+10 PV."),cura:C("Poção de Cura",{pv:20},"+20 PV."),cura_sup:C("Poção de Cura Superior",{pv:30},"+30 PV."),
tonico:C("Tônico de Esforço",{ef:10},"+10 Esforço."),mana:C("Poção de Mana",{mp:10},"+10 Mana."),
antidoto:C("Antídoto Simples",{cure:"veneno"},"Trata veneno simples."),remedio_febre:C("Remédio para Febre",{cure:"febre"},"Trata febre."),
atadura:C("Atadura",{cure:"sangue"},"Interrompe sangramento leve."),
pao_velho:F("Pão Velho",10),pao:F("Pão Fresco",15),carne_assada:F("Carne Assada",25),carne_seca:F("Carne Seca",20),
ensopado:F("Ensopado Simples",30),frutas:F("Frutas Silvestres",10),carne_ruim:F("Carne Estragada",15,{risk:1,d:"Recupera 15 de fome. Risco de febre."}),
erva:I("Erva Medicinal"),cogumelo:I("Cogumelo Tóxico"),flor:I("Flor Arcana"),raiz:I("Raiz Rubra"),osso:I("Osso Corrompido"),tecido:I("Tecido"),carne_crua:I("Carne Crua")
};
RPG.Recipes=[[["erva","erva"],"cura_menor"],[["erva","cogumelo"],"antidoto"],[["raiz","erva"],"tonico"],[["flor","erva"],"mana"],[["carne_crua"],"carne_assada"],[["carne_crua","erva"],"ensopado"],[["tecido","tecido"],"atadura"]];
})();
