/* Inimigos, aventura "O Sino sob a Lama", missões. Escolha: {t,go,fx,req,once,fight,test,rest,nt} */
(function(){
const R=RPG,E=R.E,F=s=>s.flags;
R.Foes={
 cadaver:{n:"Cadáver Errante",pv:25,d:[5,8],pr:1,df:10,xp:25,loot:[["osso",.5],["tecido",.5]]},
 lobo:{n:"Lobo Pestilento",pv:32,d:[7,11],pr:2,df:13,xp:35,st:"febre",loot:[["carne_crua",.7]]},
 saque:{n:"Saqueador Corrompido",pv:48,d:[9,13],pr:4,df:14,xp:45,st:"veneno",loot:[["cura_menor",.5],["escudo_p",.4]]},
 boss:{n:"Aberração da Peste",pv:120,d:[10,16],pr:5,df:15,xp:100,boss:1,st:"febre",parts:{cab:["Cabeça",30],bd:["Braço direito",25],be:["Braço esquerdo",25],pe:["Pernas",40]}}
};
R.Origins={
 soldado:{n:"Soldado desertor",d:"Armadura e escudo, se sua classe puder usá-los, e uma atadura.",give:u=>{const c=R.Classes[u.cls];const a=c.ar.includes("couro")?"couro":c.ar[0];if(a){u.eq.a=a;}if(c.sh)u.eq.s="escudo_p";E.give("atadura");}},
 viajante:{n:"Viajante errante",d:"Pães, carne seca e poções de cura menor.",give:()=>{E.give("pao",2);E.give("carne_seca");E.give("cura_menor",2);}},
 erudito:{n:"Erudito exilado",d:"Ervas, uma flor arcana e um tônico.",give:()=>{E.give("erva",3);E.give("flor");E.give("tonico");E.give("pao_velho");}}
};
const back=(t,go)=>({t:t||"Voltar",go:go||"vau"});
const S={
vau:{t:`Você chega a Vau Cinzento ao entardecer. As casas estão fechadas, os campos largados ao mato, e há marcas fundas de arranhões em todas as portas, como se algo tivesse tentado entrar... ou sair.\nDentro de uma capela cuja torre desabou há anos, um sino toca. Três badaladas lentas, depois silêncio.`,
 c:[{t:"Investigar a estalagem",go:"estalagem"},{t:"Investigar a capela",go:"capela_v"},{t:"Explorar as casas abandonadas",go:"casas"},{t:"Deixar o vilarejo e entrar na floresta",go:"floresta"}]},
estalagem:{t:s=>`O salão da estalagem cheira a mofo e sebo velho. Não há estalajadeiro, mas as brasas da lareira ainda estão mornas.`+(s.party.some(u=>u.id==="elian")?`\nElian vigia a porta, de braços cruzados.`:F(s).elian_gone?`\nO canto onde Elian se sentava está vazio.`:F(s).morto_elian?`\nA cadeira de Elian está vazia.`:`\nNum canto, um homem de hábito sujo afia, sem pressa, uma maça de ferro. Ele o observa como quem já esperava más notícias.`),
 c:[{t:"Falar com o homem de hábito",go:"elian_talk",req:s=>!s.party.some(u=>u.id==="elian")&&!F(s).elian_gone&&!F(s).morto_elian&&!F(s).quest_med},
 {t:"Entregar os medicamentos a Elian",req:s=>F(s).has_meds&&!s.party.some(u=>u.id==="elian")&&!F(s).elian_gone&&!F(s).morto_elian,go:"estalagem",once:"elian",fx:s=>{s.party.push(E.mk("clerigo","Elian",{id:"elian",sk:["cl1","cl2"],eq:{w:"maca",a:"couro",s:null}}));s.flags.quest_med_done=1;return "Elian confere os frascos em silêncio. \"Está tudo aqui. Vou com você. Mas não espere que eu goste disso.\" Elian entrou no grupo.";}},
 {t:"Descansar (descanso curto)",rest:"short"},{t:"Descansar (descanso longo)",rest:"long"},back()]},
elian_talk:{t:`— Não fale tão alto — diz o homem. — Meu nome é Elian. Minha irmã sumiu há três noites, quando o sino começou. Eu a procuraria, mas meus remédios acabaram, e sem eles não consigo curar nem a mim.\nEle aponta a rua. — O antigo médico morava na casa com a cruz pintada. Se trouxer o que restou das ervas e frascos dele, eu o acompanho. Não prometo gostar de você.`,
 c:[{t:"Aceitar: trazer os medicamentos",go:"estalagem",fx:s=>{s.flags.quest_med=1;return "Missão: Medicamentos do médico.";}},{t:"Recusar por enquanto",go:"estalagem"}]},
capela_v:{t:`A torre desabou sobre a nave e o telhado cedeu. A lama cobre o piso até os tornozelos, fria demais para o clima. Uma corda de sino pende do alto, imóvel, mas você jurou ouvi-la balançar. Ninguém toca o sino. Ainda assim, ele soou três vezes, e você contou cada uma.`,
 c:[{t:"Remexer a lama junto ao altar",once:"lama",fx:s=>{E.give("flor");E.give("osso");s.ch.sa=Math.max(0,s.ch.sa-2);return "Sob a lama você acha uma flor arcana e um osso enegrecido. Dedos pálidos se fecham por um instante em seu tornozelo antes de se desfazerem. Sanidade −2.";}},back()]},
casas:{t:`As portas arranhadas estão trancadas por dentro. Em algumas, há pratos postos e comida podre: a vida parou no meio da refeição. No fim da rua, uma casa se destaca: há uma cruz de tinta desbotada na porta.`,
 c:[{t:"Vasculhar as casas",once:"vasc",fx:s=>{E.give("pao_velho");E.give("tecido",2);E.give("erva");return "Você encontra pão velho, retalhos de tecido e uma erva seca.";}},{t:"Ir à casa da cruz pintada",go:"medico"},back()]},
medico:{t:`A porta da casa do médico está entreaberta. Lá dentro, algo remexe frascos. O cheiro doce de carne apodrecida sai pela fresta.`,
 c:[{t:"Entrar",fight:["saque"],once:"medfight",go:"medico2"},back("Voltar","casas")]},
medico2:{t:`Com o saqueador caído, a casa fica em silêncio. As prateleiras foram saqueadas, mas um armário atrás do balcão ainda está trancado por dentro.`,
 c:[{t:"Recolher os medicamentos",once:"meds",go:"casas",fx:s=>{E.give("remedio_febre");E.give("cura_menor",2);E.give("antidoto");s.flags.has_meds=1;return "Você recolhe remédio para febre, poções e um antídoto.";}},back("Voltar","casas")]},
floresta:{t:s=>`A floresta ao redor de Vau Cinzento está doente: troncos negros e inchados, folhas que escorrem uma seiva leitosa. Há silêncio demais.`+(F(s).entrada?`\nUma laje rachada, meio enterrada, guarda uma entrada subterrânea.`:""),
 c:[{t:"Colher ervas e frutos na orla",once:"forr",fight:["cadaver"],go:"floresta",fx:s=>{E.give("erva",2);E.give("frutas");E.give("cogumelo");return "Entre as raízes você colhe ervas, frutas e um cogumelo tóxico.";}},
 {t:"Seguir os rastros no barro",once:"rast",fight:["lobo"],go:"floresta",fx:s=>{s.flags.entrada=1;return "Os rastros levam a uma laje rachada, meio enterrada: uma entrada subterrânea.";}},
 {t:"Seguir o som de um gemido",go:"sobrev",req:s=>!F(s).sdone},
 {t:"Descer pela laje rachada",go:"cap_in",req:s=>F(s).entrada},
 {t:"Montar acampamento",go:"acamp"},back("Voltar a Vau Cinzento")]},
sobrev:{t:`Um homem de meia-idade está caído sob um tronco, a perna aberta por dentes. — Bento — diz, ofegante. — Vi uma laje sob as raízes, ao norte... aquilo desceu por lá. Por favor.`,
 c:[{t:"Tratar com uma atadura",req:s=>s.inv.atadura,once:"sdone",go:"floresta",fx:s=>{E.take("atadura");s.flags.entrada=1;s.flags.helped=1;E.give("raiz");const m=E.xp(10);return "Bento chora de alívio e entrega uma raiz rubra, mostrando onde fica a entrada subterrânea. +10 XP "+m.join(" ");}},
 {t:"Dar uma poção de cura menor",req:s=>s.inv.cura_menor,once:"sdone",go:"floresta",fx:s=>{E.take("cura_menor");s.flags.entrada=1;s.flags.helped=1;E.xp(10);return "Bento bebe a poção e aponta o caminho da entrada subterrânea. +10 XP";}},
 {t:"Ignorá-lo e seguir em frente",once:"sdone",go:"floresta",fx:s=>{s.flags.ignored=1;s.ch.sa=Math.max(0,s.ch.sa-2);let m="Os gemidos o seguem por muito tempo. Sanidade −2.";const el=s.party.find(u=>u.id==="elian");if(el){s.party=s.party.filter(u=>u!==el);s.flags.elian_gone=1;m+="\nElian para de andar. — Eu mesmo vi o que a indiferença fez com esta terra. — E vai embora. Elian abandonou o grupo.";}return m;}}]},
acamp:{t:`Uma clareira seca e um círculo de pedras de fogueiras antigas. Não é seguro, mas é o melhor lugar para descansar na floresta.`,
 c:[{t:"Descanso curto",rest:"short"},{t:"Descanso longo",rest:"long"},back("Voltar","floresta")]},
cap_in:{t:`Degraus de pedra descem até uma capela enterrada, intacta pela umidade como se fosse mais velha que a própria terra. Bancos de pedra, nichos com velas apagadas, um corredor longo até um portão de ferro. Há um registro aberto sobre um atril.`,
 c:[{t:"Ler o registro do sacerdote",go:"registro"},
 {t:"Procurar a sala escondida nos nichos (Sabedoria)",once:"sala",test:{a:"sab",dc:11},ok:[null,s=>{E.give("cura");E.give("mana");E.give("escudo_r");E.give("pao",2);return "Você percebe uma pedra solta: uma sala de provisões esquecida. Poção de cura, poção de mana, escudo reforçado e pães!";}],bad:[null,s=>{E.give("pao_velho");return "Você só encontra um pedaço de pão velho. Algo ali lhe escapou.";}]},
 {t:"Ir ao portão de ferro",go:"puzzle"},back("Subir à floresta","floresta")]},
registro:{t:`"Eu, Aldor, último sacerdote desta capela. Nós o prendemos ao altar: raiz, corrente e uma oração mal feita. Dizem que tentamos tomar o que pertencia a um deus, e o deus respondeu. O sino que ouvi não toca por ordem de ninguém: avisa que a coisa ainda desperta.\nPara abrir o portão, esculpi o nome do sino em cifra. Cada letra avança tantas casas quantas badaladas ele dá."`,
 c:[{t:"Fechar o registro",go:"cap_in",once:"reg",fx:s=>{s.flags.regis=1;E.xp(5);return "Você anota a pista. +5 XP";}}]},
puzzle:{pz:{q:"VLQR",ans:"sino",hints:["Quantas vezes o sino soou na capela do vilarejo?","Cada letra avança 3 casas no alfabeto. Volte 3 casas para decifrar.","V→S, L→I, Q→N, R→O."],go:"altar",xp:15},
 t:`O portão de ferro tem uma inscrição entalhada: um nome em cifra. Abaixo, uma moldura vazia espera ser preenchida.`,c:[back("Voltar","cap_in")]},
altar:{t:`O portão se abre. A abside é um pântano de lama negra. No altar, preso por raízes e correntes, repousa algo que já foi humano: cabeça deformada, dois braços longos demais e pernas fundidas à pedra. Ele ergue o rosto e o sino toca, dentro de seu próprio peito.`,
 c:[{t:"Enfrentar a Aberração da Peste",fight:["boss"],once:"boss",go:"fragmento"},back("Recuar","cap_in")]},
fragmento:{t:`Quando a coisa cai, as correntes se soltam. No altar, entre as raízes, resta um fragmento escuro do tamanho de uma mão, frio, que parece murmurar. Você sente que ele escolhe quem o toca.`,
 c:[{t:"Destruir o fragmento",go:"fim_d"},{t:"Levar o fragmento",go:"fim_l"},{t:"Deixá-lo no altar",go:"fim_n"}]},
fim_d:{end:1,title:"Final: Silêncio",t:`Você esmaga o fragmento com a base da arma e a capela inteira geme. O sino toca uma última vez, e então, enfim, cala. Vau Cinzento amanhece. As portas se abrem, devagar. Mas a lama não desaparece, e algo, fundo no solo, tomou nota do seu rosto.`},
fim_l:{end:1,title:"Final: Portador",t:`O fragmento esquenta em sua mão e some sob a pele, como uma moeda engolida. Você sai da capela mais forte, sem fome e sem medo. Só o sonho voltou: agora você é quem toca o sino, e sabe aonde ele chama.`},
fim_n:{end:1,title:"Final: Vigília",t:`Você deixa o fragmento no altar, refaz as correntes como pode e sela o portão. O sino não volta a tocar, mas o vilarejo nunca mais dorme em paz: algo espera, paciente. Você parte sem saber se salvou Vau Cinzento ou apenas adiou a pergunta.`}
};
R.Story={scenes:S,start:"vau",
 quests:[
  {id:"main",t:"Descobrir a origem do sino",d:s=>s.flags.boss?"A Aberração foi derrotada. Resta decidir o destino do fragmento.":s.flags.entrada?"Você achou a entrada subterrânea na floresta.":"Investigue Vau Cinzento e a floresta."},
  {id:"med",t:"Medicamentos do médico",show:s=>s.flags.quest_med,d:s=>s.flags.quest_med_done?"Concluída: Elian se uniu ao grupo.":s.flags.has_meds?"Leve os medicamentos a Elian, na estalagem.":"Procure os remédios na casa da cruz pintada."}
 ]};
})();
