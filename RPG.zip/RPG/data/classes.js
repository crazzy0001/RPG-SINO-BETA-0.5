/* 12 classes, 4 habilidades cada (a primeira é a inicial). c=[recurso,custo]; e=evolução (sobrescreve campos). */
(function(){
const A=["vig","for","agi","int","pre","sab","sor"];
RPG.Attr=A; RPG.AttrN={vig:"Vigor",for:"Força",agi:"Agilidade",int:"Intelecto",pre:"Presença",sab:"Sabedoria",sor:"Sorte"};
const S=(id,n,c,k,o,e)=>Object.assign({id,n,c,k},o,{e:e||{}});
const K=(n,a,r,g,w,ar,sh,st,goal,sk)=>({n,a:Object.fromEntries(A.map((x,i)=>[x,a[i]])),r,g,w,ar,sh,st,goal,sk});
RPG.Classes={
guerreiro:K("Guerreiro",[4,4,2,1,2,2,1],[35,8,15,24],[10,1,3,3],["espada","machado","lanca"],["couro","reforcada","malha","pesada"],1,"espada","Descobrir que força desperta em você, e se ela serve a alguém além de você mesmo.",[
 S("g1","Golpe Brutal",["ef",5],"atk",{b:8},{b:13}),
 S("g2","Retaliação",["ef",5],"ret",{d:6,t:2},{d:11}),
 S("g3","Postura de Combate",["ef",5],"guard",{r:8,t:2,tg:"self"},{r:13,t:3}),
 S("g4","Rompedor de Defesa",["ef",8],"atk",{b:6,sh:[5,2]},{b:11,sh:[8,2]})]),
cavaleiro:K("Cavaleiro",[4,3,1,1,3,3,1],[35,12,14,25],[11,1,3,3],["espada","lanca","maca"],["reforcada","malha","pesada"],1,"espada","Cumprir um juramento antigo, ainda que o senhor a quem o fez já não exista.",[
 S("c1","Provocação",["ef",5],"taunt",{t:2},{}),
 S("c2","Defesa Absoluta",["ef",8],"guard",{r:10,t:1,tg:"self"},{r:15}),
 S("c3","Proteção Aliada",["ef",5],"absorb",{a:8},{a:13}),
 S("c4","Juramento de Ferro",["ef",5],"guard",{r:6,t:3,tg:"self"},{r:9})]),
ladino:K("Ladino",[2,1,4,2,2,2,3],[30,10,25,22],[5,1,7,3],["adaga","arco","besta"],["couro"],0,"adaga","Recuperar algo que lhe foi tirado e descobrir quem o levou.",[
 S("l1","Ataque pelas Costas",["ef",5],"atk",{b:8},{b:13}),
 S("l2","Corte Rápido",["ef",8],"multi",{n:2,b:4},{b:7}),
 S("l3","Esquiva Instintiva",["ef",5],"dodge",{},{}),
 S("l4","Golpe Traiçoeiro",["ef",8],"atk",{b:6,bl:[3,2]},{b:10,bl:[3,3]})]),
cacador:K("Caçador",[2,2,4,2,1,4,1],[32,10,23,24],[6,1,6,3],["arco","besta","lanca","adaga"],["couro","reforcada"],0,"arco","Rastrear a coisa que vem devastando as florestas antes que ela o rastreie.",[
 S("ca1","Marcar Presa",["ef",5],"mark",{b:5,t:3},{b:8,t:4}),
 S("ca2","Disparo Preciso",["ef",5],"atk",{b:8},{b:13}),
 S("ca3","Armadilha Improvisada",["ef",8],"mag",{d:7,root:1},{d:12,root:2}),
 S("ca4","Conhecedor de Monstros",["ef",5],"scan",{},{})]),
bruxo:K("Bruxo",[1,1,2,2,4,4,2],[30,35,12,27],[5,4,2,4],["adaga","cajado"],[],0,"adaga","Quitar um pacto feito em desespero, antes que o credor venha cobrar.",[
 S("b1","Marca Profana",["mp",5],"mag",{d:0,dt:[4,3]},{dt:[7,3]}),
 S("b2","Cobrança do Pacto",null,"pact",{p:5,m:12},{m:18}),
 S("b3","Correntes Profanas",["mp",8],"mag",{d:6,root:1},{d:10,root:2}),
 S("b4","Sangue do Pacto",null,"nb",{p:8,b:10,n:2},{b:15})]),
clerigo:K("Clérigo",[3,1,1,2,3,4,2],[32,30,14,26],[7,3,3,4],["maca","cajado"],["couro","reforcada"],1,"maca","Manter acesa uma fé que o mundo parece decidido a apagar.",[
 S("cl1","Prece Restauradora",["mp",8],"heal",{h:10},{h:16}),
 S("cl2","Repulsa Sagrada",["mp",5],"mag",{d:9},{d:15}),
 S("cl3","Bênção Protetora",["mp",8],"guard",{r:8,t:2,tg:"ally"},{r:12,t:3}),
 S("cl4","Luz Purificadora",["mp",8],"cure",{},{})]),
necromante:K("Necromante",[1,1,1,4,2,4,3],[30,32,12,28],[5,4,2,4],["foice","cajado","adaga"],["couro"],0,"foice","Entender por que os mortos o chamam pelo nome.",[
 S("n1","Servo Reanimado",["mp",12],"summon",{hp:12,d:5},{hp:20,d:8}),
 S("n2","Mão Cadavérica",["mp",8],"mag",{d:8,sh:[5,2]},{d:13,sh:[8,2]}),
 S("n3","Drenagem Vital",["mp",8],"mag",{d:7,dr:6},{d:11,dr:10}),
 S("n4","Ossos Protetores",["mp",8],"guard",{r:10,t:2,tg:"self"},{r:15,t:3})]),
ocultista:K("Ocultista",[1,1,2,4,2,4,2],[30,38,12,30],[5,5,2,5],["adaga","cajado"],[],0,"adaga","Decifrar o conhecimento proibido que o persegue desde o sonho.",[
 S("o1","Selo de Restrição",["mp",8],"mag",{d:5,wk:[5,2]},{d:9,wk:[8,2]}),
 S("o2","Leitura Profana",["mp",5],"scan",{},{}),
 S("o3","Círculo de Proteção",["mp",8],"guard",{r:6,t:2,tg:"party"},{r:10,t:3}),
 S("o4","Ruptura Oculta",["mp",12],"mag",{d:12,pr:5},{d:18,pr:8})]),
alquimista:K("Alquimista",[2,1,2,4,2,2,3],[31,15,22,23],[6,2,6,3],["adaga"],["couro"],0,"adaga","Encontrar a cura para um mal que nenhum livro descreve.",[
 S("a1","Frasco Corrosivo",["mp",5],"mag",{d:8,sh:[5,2]},{d:13,sh:[8,2]}),
 S("a2","Composto Revigorante",["mp",8],"heal",{h:10},{h:16}),
 S("a3","Névoa Tóxica",["mp",8],"dotAll",{d:4,t:2},{d:7,t:3}),
 S("a4","Mistura Instável",["mp",8],"rand",{},{up:1})]),
druida:K("Druida",[3,2,2,2,1,4,2],[33,28,17,27],[8,3,4,4],["cajado","foice","lanca","arco"],[],0,"cajado","Descobrir o que adoece a floresta e se ainda há raiz sã.",[
 S("d1","Raízes Aprisionadoras",["mp",5],"mag",{d:5,root:1},{d:9,root:2}),
 S("d2","Pele Selvagem",["mp",5],"guard",{r:8,t:2,tg:"self"},{r:13}),
 S("d3","Espinhos Vivos",["mp",8],"ret",{d:6,t:2},{d:10}),
 S("d4","Regeneração Natural",["mp",8],"regen",{h:4,t:3},{h:7})]),
mago:K("Mago",[1,1,2,5,2,4,1],[30,30,12,29],[5,4,2,5],["cajado","adaga"],[],0,"cajado","Provar que o saber, e não a fé, pode explicar o que está acontecendo.",[
 S("m1","Projétil Arcano",["mp",5],"mag",{d:9},{d:15}),
 S("m2","Barreira Mágica",["mp",8],"guard",{r:12,t:2,tg:"self"},{r:18}),
 S("m3","Explosão Elemental",["mp",8],"mag",{d:12,dt:[3,2]},{d:18,dt:[5,2]}),
 S("m4","Concentração Arcana",["mp",5],"nb",{b:8,n:1},{b:13})]),
monge:K("Monge",[3,3,4,1,2,2,1],[34,15,25,30],[9,2,7,5],["manoplas","cajado"],["couro"],0,"manoplas","Levar a disciplina de uma vida a um lugar onde ela será posta à prova.",[
 S("mo1","Punho Ascendente",["ef",5],"atk",{b:7},{b:12}),
 S("mo2","Respiração Interior",["mp",5],"esf",{v:10},{v:16}),
 S("mo3","Sequência de Golpes",["ef",8],"multi",{n:3,b:3},{b:6}),
 S("mo4","Corpo Disciplinado",["ef",5],"guard",{r:8,t:2,tg:"self"},{r:13})])
};
RPG.SK={}; for(const k in RPG.Classes)RPG.Classes[k].sk.forEach(s=>RPG.SK[s.id]=s);
})();
