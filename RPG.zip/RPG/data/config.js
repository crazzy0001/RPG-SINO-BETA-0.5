/* Configurações centrais do jogo. Todo valor ajustável de balanceamento fica aqui. */
window.RPG = window.RPG || {};
RPG.Config = {
  VERSION: "0.1.0",
  SAVE_VERSION: 1,
  SAVE_KEY: "rpg_dark_save_v1",
  SETTINGS_KEY: "rpg_dark_settings_v1",
  AUTOSAVE_MS: 30000,        // salvamento periódico (além dos salvamentos por evento)
  POINTS_PER_LEVEL: 3,       // pontos de atributo por nível (único local; usado na Etapa 2)
  MAX_LEVEL_V1: 4,
  MAX_PARTY: 4
};
Object.assign(RPG.Config,{
  XP:[0,0,30,70,110],                 // XP acumulado para alcançar o nível (índice = nível)
  HUNGER_MOVE:2,                      // fome perdida a cada mudança de cena
  HUNGER:{hungryAtk:-1,starvePV:3},   // efeitos de fome (Faminto: ataque; Inanição: PV por cena)
  REST:{short:0.35,long:0.8,saS:4,saL:10,hS:8,hL:15,ev:0.25}, // fração recuperada, sanidade, fome gasta, chance de evento
  FLEE_BASE:40, FLEE_AGI:3,           // chance de fuga = base + AGI*3 - 5*inimigos
  ENEMY_ATK:4                          // bônus de ataque dos inimigos (d20 + bônus vs 10 + AGI)
});
