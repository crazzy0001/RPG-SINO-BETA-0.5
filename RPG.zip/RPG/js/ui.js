/* Interface: criação, cena, menu (ficha/itens/grupo/missões), nível, combate, encerramento. */
(function(){
const R=RPG,E=R.E,Cb=R.Combat,$=id=>document.getElementById(id);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const bar=(l,c,m,k)=>`<div class="bar ${k}"><i style="width:${m?Math.max(0,c)/m*100:0}%"></i><span>${l} ${Math.max(0,Math.ceil(c))}/${m}</span></div>`;
const bars=u=>bar("PV",u.pv,u.pvM,"pv")+(u.summon?"":bar("Mana",u.mp,u.mpM,"mp")+bar("Esforço",u.ef,u.efM,"ef")+bar("Sanidade",u.sa,u.saM,"sa")+bar("Fome "+E.hs(u.fome),u.fome,100,"fo"));
const U=R.UI=R.UI||{};
U.toast=function(m){const t=$("toast");t.textContent=m;t.hidden=false;clearTimeout(U._t);U._t=setTimeout(()=>t.hidden=true,4000);};
const paras=t=>String(t).split("\n").map(p=>"<p>"+esc(p)+"</p>").join("");
const desc=s=>{const p=[];if(s.b!=null&&s.k!=="nb"&&s.k!=="mark")p.push("+"+s.b+" dano");if(s.d)p.push(s.d+" dano");if(s.k==="multi")p.push(s.n+" golpes");if(s.h&&s.k!=="regen")p.push("cura "+s.h);if(s.k==="regen")p.push("+"+s.h+" PV/turno por "+s.t+"t");
 if(s.r)p.push("−"+s.r+" dano recebido"+(s.t?" por "+s.t+"t":""));if(s.root)p.push("prende "+s.root+"t");if(s.sh)p.push("−"+s.sh[0]+" proteção inimiga");if(s.wk)p.push("−"+s.wk[0]+" dano inimigo");if(s.dt)p.push(s.dt[0]+" dano/turno por "+s.dt[1]+"t");
 if(s.bl)p.push("sangramento "+s.bl[1]+"t");if(s.dr)p.push("recupera "+s.dr+" PV");if(s.pr)p.push("ignora "+s.pr+" proteção");if(s.k==="ret")p.push("devolve "+s.d+" a quem atacar");if(s.k==="mark")p.push("+"+s.b+" dano no alvo por "+s.t+"t");
 if(s.k==="nb")p.push("próximas "+s.n+" magia(s) +"+s.b);if(s.k==="pact")p.push("−"+s.p+" PV, +"+s.m+" Mana");if(s.k==="esf")p.push("+"+s.v+" Esforço");if(s.k==="dotAll")p.push(s.d+" dano/turno em todos por "+s.t+"t");
 if(s.k==="taunt")p.push("atrai ataques por "+s.t+"t");if(s.k==="summon")p.push("servo "+s.hp+" PV, "+s.d+" dano");if(s.k==="absorb")p.push("absorve "+s.a);if(s.k==="dodge")p.push("evita o próximo ataque");if(s.k==="scan")p.push("revela dados do inimigo");if(s.k==="cure")p.push("remove veneno/febre");if(s.k==="rand")p.push("efeito aleatório");
 return p.join("; ")+(s.c?" · custo "+s.c[1]+" "+{ef:"Esforço",mp:"Mana"}[s.c[0]]:"");};
U.desc=desc;
const save=()=>R.Save.save();

/* ---------- Criação ---------- */
U.cr={};
U.create=function(){U.cr={};const S=R.Save.current;S.stage="criacao";R.Game.show("create",false);U.crClass();};
U.crClass=function(){$("create-body").innerHTML="<h2>Escolha sua classe</h2>"+Object.keys(R.Classes).map(k=>{const c=R.Classes[k];return `<button class="btn" data-cls="${k}"><b>${c.n}</b><small>PV ${c.r[0]} · Mana ${c.r[1]} · Esforço ${c.r[2]} · Sanidade ${c.r[3]}<br>${R.Attr.map(a=>R.AttrN[a].slice(0,3)+" "+c.a[a]).join(" · ")}<br>Habilidade inicial: ${c.sk[0].n}</small></button>`;}).join("");};
U.crDetail=function(k){U.cr.cls=k;const c=R.Classes[k];
 $("create-body").innerHTML=`<h2>${c.n}</h2><div class="panel"><b>Objetivo:</b> ${esc(c.goal)}</div><label class="fld">Nome do personagem<input id="cr-name" maxlength="20" value="${esc(U.cr.name||"")}" autocomplete="off"></label><h3>Origem</h3>`+Object.keys(R.Origins).map(o=>`<button class="btn" data-origin="${o}"><b>${R.Origins[o].n}</b><small>${R.Origins[o].d}</small></button>`).join("")+`<button class="btn ghost" data-action="cr-back">Trocar de classe</button>`;};
U.crStart=function(origin){const name=($("cr-name").value||"").trim()||"Andarilho";const S=R.Save.current,k=U.cr.cls;
 S.ch=E.mk(k,name);S.party=[];S.inv={};S.flags={};S.stats={combats:0};S.scene=R.Story.start;S.notice="";
 R.Origins[origin].give(S.ch);S.stage="aventura";save();
 $("create-body").innerHTML=`<h2>O sonho</h2>${paras(`Antes de partir, ${name} sonhou. Um sino afundava devagar numa lama escura, e cada badalada chamava por um nome que não era o seu... e era. Ao acordar, a vida anterior já não servia. Nenhuma ordem, nenhum destino: apenas a vontade inexplicável de ir.\nObjetivo: ${R.Classes[k].goal}`)}<button class="btn primary" data-action="begin">Começar a jornada</button>`;};

/* ---------- Cena ---------- */
U.play=function(){const S=R.Save.current,ch=S.ch,sc=R.Story.scenes[S.scene];R.Game.show("play",false);
 if(sc.end)return U.finish(sc);
 const txt=typeof sc.t==="function"?sc.t(S):sc.t;
 const cs=(sc.c||[]).filter(c=>!c.req||c.req(S)).filter(c=>!c.once||!S.flags[c.once]||c.rest);U._cs=cs;
 let h=`<div class="status"><b>${esc(ch.name)}</b> · ${R.Classes[ch.cls].n} · Nv ${ch.lvl}`+bars(ch)+`</div>`;
 if(ch.pend)h+=`<button class="btn primary" data-action="level">★ Subir de nível (${ch.pend.pts} pontos)</button>`;
 if(S.notice){h+=`<div class="notice">${paras(S.notice)}</div>`;S.notice="";}
 h+=`<div class="scene">${paras(txt)}</div>`;
 if(sc.pz){h+=`<div class="panel"><div class="cipher">${sc.pz.q}</div><input id="pz-in" placeholder="Digite a palavra" autocomplete="off"><button class="btn" data-action="pz-ok">Tentar</button><button class="btn ghost" data-action="pz-hint">Pedir ajuda (−3 PV)</button><div id="pz-h">${(S.flags.hints||0)>0?sc.pz.hints.slice(0,S.flags.hints).map(x=>"<p>"+esc(x)+"</p>").join(""):""}</div></div>`;}
 h+=cs.map((c,i)=>`<button class="btn" data-ch="${i}">${esc(c.t)}</button>`).join("");
 h+=`<div class="nav"><button class="btn" data-action="menu">Ficha e itens</button><button class="btn" data-action="to-title">Menu</button></div>`;
 $("play-body").innerHTML=h;};
U.pick=function(c){const S=R.Save.current;
 if(c.rest){const r=E.rest(c.rest);S.notice=r.msg;if(r.fight)return U.fight(r.fight,null,()=>U.play());save();return U.play();}
 if(c.test){const u=S.ch,r=E.d20(),t=r+u.at[c.test.a],ok=t>=c.test.dc;if(c.once)S.flags[c.once]=1;const x=ok?c.ok:c.bad;
  S.notice=`Teste de ${R.AttrN[c.test.a]}: ${r} + ${u.at[c.test.a]} = ${t} (dificuldade ${c.test.dc}). `+(ok?"Sucesso!":"Falha.")+"\n"+x[1](S);save();return U.play();}
 if(c.fight)return U.fight(c.fight,c,()=>U.play());
 U.done(c);};
U.done=function(c,pre){const S=R.Save.current;if(c.once)S.flags[c.once]=1;let m=(pre?pre+"\n":"")+(c.fx?c.fx(S)||"":"");
 if(c.go&&c.go!==S.scene){S.scene=c.go;const w=E.tick();if(w.length)m+=(m?"\n":"")+w.join(" ");}
 const r=E.reap();r.dead.forEach(u=>{m+="\n☠ "+u.name+" morreu.";});S.notice=m.trim();
 if(r.hero)return U.end("Você sucumbiu aos seus ferimentos.");save();U.play();};

/* ---------- Quebra-cabeça ---------- */
U.pzTry=function(){const S=R.Save.current,p=R.Story.scenes[S.scene].pz,v=($("pz-in").value||"").trim().toLowerCase();
 if(v===p.ans){S.flags.pz=1;const m=E.xp(p.xp);S.notice="Você insere a palavra. As letras brilham e o portão se abre. +"+p.xp+" XP "+m.join(" ");S.scene=p.go;save();U.play();}
 else U.toast("Nada acontece. Pode tentar de novo.");};
U.pzHint=function(){const S=R.Save.current,p=R.Story.scenes[S.scene].pz;if((S.flags.hints||0)>=p.hints.length)return U.toast("Não há mais dicas.");
 S.ch.pv-=3;if(S.ch.pv<=0)return U.end("A ajuda custou a sua última gota de vida.");S.flags.hints=(S.flags.hints||0)+1;save();U.play();};

/* ---------- Menu ---------- */
U.tab="ficha";
U.menu=function(t){U.tab=t||U.tab;const S=R.Save.current,ch=S.ch;R.Game.show("menu",true);
 let h=`<div class="tabs">${[["ficha","Ficha"],["itens","Itens"],["grupo","Grupo"],["missoes","Missões"]].map(x=>`<button class="${U.tab===x[0]?"on":""}" data-tab="${x[0]}">${x[1]}</button>`).join("")}</div>`;
 if(U.tab==="ficha"){h+=`<h2>${esc(ch.name)} — ${R.Classes[ch.cls].n} Nv ${ch.lvl}</h2>`+(ch.lvl<4?`<p class="hint">XP ${ch.xp}/${RPG.Config.XP[ch.lvl+1]}</p>`:"")+bars(ch)+`<h3>Atributos</h3><div class="attrs">${R.Attr.map(a=>`<span>${R.AttrN[a]} <b>${ch.at[a]}</b></span>`).join("")}</div>`
  +`<h3>Equipamento</h3><p>Arma: ${R.Items[ch.eq.w].n}<br>Armadura: ${R.Items[ch.eq.a].n} (proteção total ${E.armor(ch)})<br>Escudo: ${ch.eq.s?R.Items[ch.eq.s].n:"nenhum"}</p><h3>Habilidades</h3>`+ch.sk.map(id=>{const s=E.sk(ch,id);return `<div class="panel"><b>${s.n}</b>${ch.ev.includes(id)?" ★":""}<br><small>${desc(s)}</small></div>`;}).join("")
  +(ch.sa<=0?`<p class="warn">Sanidade esgotada: −2 nos ataques.</p>`:"");}
 if(U.tab==="itens"){const m=E.members();U.tgt=Math.min(U._tg||0,m.length-1);
  h+=`<h2>Itens</h2>`+(m.length>1?`<label class="fld">Usar em<select id="tgt">${m.map((u,i)=>`<option value="${i}" ${i===U.tgt?"selected":""}>${esc(u.name)}</option>`).join("")}</select></label>`:"");
  h+=`<h3>Equipado</h3>`+[["w","Arma"],["a","Armadura"],["s","Escudo"]].map(x=>{const id=ch.eq[x[0]];return `<div class="row"><span>${x[1]}: ${id?R.Items[id].n:"—"}</span>${id&&id!=="roupa"?`<button class="mini" data-un="${x[0]}">Remover</button>`:""}</div>`;}).join("");
  h+=`<h3>Inventário</h3>`;const ids=Object.keys(S.inv);if(!ids.length)h+=`<p class="hint">Inventário vazio.</p>`;
  ids.forEach(id=>{const it=R.Items[id],eq=["w","a","s"].includes(it.t);h+=`<div class="panel"><b>${it.n}</b> ×${S.inv[id]} <small>(${R.Rar[it.r]})</small><br><small>${it.d||(it.t==="w"?"Dano "+it.d[0]+"–"+it.d[1]+" ("+R.AttrN[it.s]+")":it.p!=null?"Proteção +"+it.p:"")}</small><br>`+(it.e?`<button class="mini" data-use="${id}">Usar</button>`:"")+(eq?`<button class="mini" data-eq="${id}">Equipar</button>`:"")+`</div>`;});
  const rc=R.Recipes.filter(r=>{const n={};r[0].forEach(i=>n[i]=(n[i]||0)+1);return Object.keys(n).every(i=>(S.inv[i]||0)>=n[i]);});
  h+=`<h3>Fabricação</h3>`+(rc.length?rc.map(r=>`<button class="btn" data-craft="${R.Recipes.indexOf(r)}">${r[0].map(i=>R.Items[i].n).join(" + ")} → ${R.Items[r[1]].n}</button>`).join(""):`<p class="hint">Sem ingredientes para nenhuma receita.</p>`);}
 if(U.tab==="grupo"){h+=`<h2>Grupo (${1+S.party.length}/${RPG.Config.MAX_PARTY})</h2>`+E.members().map(u=>`<div class="panel"><b>${esc(u.name)}</b> — ${R.Classes[u.cls].n} Nv ${u.lvl}${u.id==="elian"?`<br><small>Desconfiado, cuidadoso e pessimista. Procura a irmã desaparecida.</small>`:""}${bars(u)}${Object.keys(u.cond).filter(k=>k!=="t").map(k=>`<span class="tag">${k}${u.cond[k]>1?" (estágio "+["","inicial","avançado","crítico"][u.cond[k]]+")":""}</span>`).join("")}</div>`).join("")+(S.flags.morto_elian?`<p class="hint">Elian morreu e não pode ser revivido.</p>`:"");}
 if(U.tab==="missoes"){h+=`<h2>Missões</h2>`+R.Story.quests.filter(q=>!q.show||q.show(S)).map(q=>`<div class="panel"><b>${q.t}</b><br><small>${q.d(S)}</small></div>`).join("");}
 h+=`<button class="btn" data-action="back">Voltar à aventura</button>`;$("menu-body").innerHTML=h;};
U.menuBack=function(){U.play();};

/* ---------- Nível ---------- */
U.level=function(){const u=R.Save.current.ch,p=u.pend;if(!p)return;U.lv=U.lv||{a:{},s:null,e:null};R.Game.show("level",true);U.lvDraw();};
U.lvDraw=function(){const u=R.Save.current.ch,p=u.pend,v=U.lv,used=Object.values(v.a).reduce((a,b)=>a+b,0),left=p.pts-used;
 let h=`<h2>Nível ${u.lvl}</h2><p>Distribua <b>${left}</b> ponto(s):</p>`+R.Attr.map(a=>`<div class="row"><span>${R.AttrN[a]} <b>${u.at[a]+(v.a[a]||0)}</b></span><span><button class="mini" data-lv="-${a}">−</button><button class="mini" data-lv="+${a}" ${left?"":"disabled"}>+</button></span></div>`).join("");
 if(p.skill){h+=`<h3>Aprender habilidade</h3>`+R.Classes[u.cls].sk.filter(s=>!u.sk.includes(s.id)).map(s=>`<button class="btn ${v.s===s.id?"primary":""}" data-lvs="${s.id}"><b>${s.n}</b><small>${desc(s)}</small></button>`).join("");}
 if(p.evo){h+=`<h3>Evoluir habilidade</h3>`+u.sk.filter(id=>!u.ev.includes(id)).map(id=>{const s=Object.assign({},R.SK[id],R.SK[id].e);return `<button class="btn ${v.e===id?"primary":""}" data-lve="${id}"><b>${R.SK[id].n}</b><small>Evolui: ${desc(s)}</small></button>`;}).join("");}
 const ok=left===0&&(!p.skill||v.s)&&(!p.evo||v.e);
 h+=`<button class="btn primary" data-action="lv-ok" ${ok?"":"disabled"}>Confirmar</button><button class="btn" data-action="back">Decidir depois</button>`;$("level-body").innerHTML=h;};

/* ---------- Combate ---------- */
U.fight=function(ids,c,after){const S=R.Save.current;U._after=after;U._fc=c;U.pl={};Cb.start(ids,null);R.Game.show("combat",false);U.cbDraw();};
U.cbDraw=function(){const st=Cb.st,S=R.Save.current;if(!st)return;const tg=Cb.targets(),al=Cb.allies();
 let h=`<h2>Combate — turno ${st.turn}</h2><div class="foes">`+st.foes.map(f=>`<div class="panel ${f.pv<=0?"dead":""}"><b>${esc(f.name)}</b>${bar("PV",f.pv,f.pvM,"pv")}${f.p?Object.values(f.p).map(p=>`<small>${p.n}: ${Math.max(0,p.hp)}/${p.max}</small>`).join(" · "):""}<small> Def ${f.df} · Prot ${f.pr}</small></div>`).join("")+`</div><h3>Seu grupo</h3>`;
 st.party.forEach((u,i)=>{if(u.pv<=0){h+=`<div class="panel dead"><b>${esc(u.name)}</b> caiu</div>`;return;}
  h+=`<div class="panel"><b>${esc(u.name)}</b>${bars(u)}`;
  if(!u.summon){const o=Cb.opts(u),p=U.pl[i]=U.pl[i]||{a:"atk",t:0},cur=o.find(x=>x.v===p.a)||o[0];if(cur.v!==p.a){p.a=cur.v;}
   h+=`<select data-act="${i}">${o.map(x=>`<option value="${x.v}" ${x.v===p.a?"selected":""} ${x.ok===false?"disabled":""}>${esc(x.l)}</option>`).join("")}</select>`;
   if(cur.tg!=="none"){const L=cur.tg==="foe"?tg.map(x=>x.l):al.map(x=>x.name+" ("+x.pv+"/"+x.pvM+")");h+=`<select data-tg="${i}">${L.map((l,j)=>`<option value="${j}" ${j===p.t?"selected":""}>${esc(l)}</option>`).join("")}</select>`;}}
  else h+=`<small>Age sozinho.</small>`;h+=`</div>`;});
 h+=`<button class="btn primary" data-action="turn">Confirmar turno</button><div class="log" id="log">${st.log.slice(-14).map(l=>"<p>"+esc(l)+"</p>").join("")}</div>`;
 $("combat-body").innerHTML=h;const l=$("log");if(l)l.scrollTop=l.scrollHeight;};
U.cbTurn=function(){const st=Cb.st;st.plan={};Object.keys(U.pl).forEach(i=>st.plan[i]=U.pl[i]);Cb.round();
 if(st.over){const res=Cb.finish();const c=U._fc;
  if(res.res==="dead")return U.end("Você tombou em combate.");
  const m=res.msg.join("\n");
  if(res.res==="flee"){S2().notice="Você fugiu.\n"+m;save();return U.play();}
  if(c)return U.done(c,m);S2().notice=(S2().notice?S2().notice+"\n":"")+m;save();return U.play();}
 U.cbDraw();};
const S2=()=>R.Save.current;

/* ---------- Encerramento ---------- */
U.summary=function(){const S=R.Save.current,ch=S.ch;return `<div class="panel"><p>${esc(ch.name)} — ${R.Classes[ch.cls].n}, nível ${ch.lvl}</p><p>Tempo de jogo: ${R.Save.formatTime(S.playtimeSec)}</p><p>Combates: ${S.stats.combats}</p><p>Companheiros no fim: ${S.party.map(u=>u.name).join(", ")||"nenhum"}${S.flags.morto_elian?" (Elian morreu)":""}${S.flags.elian_gone?" (Elian abandonou o grupo)":""}</p><p>${S.flags.helped?"Você ajudou o sobrevivente.":S.flags.ignored?"Você ignorou o sobrevivente.":""}</p></div>`;};
U.finish=function(sc){R.Game.show("end",false);$("end-body").innerHTML=`<h2>${esc(sc.title)}</h2>${paras(sc.t)}<h3>Resumo da jornada</h3>${U.summary()}<button class="btn primary" data-action="end-new">Nova jornada</button>`;R.Save.remove();};
U.end=function(why){const h=`<h2>Fim da jornada</h2>${paras(why+" A maldição leva mais um nome. Tudo o que você construiu se perde.")}<h3>Resumo da jornada</h3>${U.summary()}<button class="btn primary" data-action="end-new">Nova jornada</button>`;
 R.Game.show("end",false);$("end-body").innerHTML=h;R.Save.remove();};
})();
