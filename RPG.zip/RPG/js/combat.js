/* Combate por turnos. Lógica pura (sem DOM); a interface fica em ui.js. */
(function(){
const R=RPG,E=R.E,C=R.Config,ri=E.ri,d20=E.d20;
const fl=(u)=>u.t;
const Cb=R.Combat={st:null,
 start(ids,done){const S=E.S(),party=E.members();
  party.forEach(u=>{u.t={dot:[]};});
  const foes=ids.map((id,i)=>{const b=R.Foes[id],f=JSON.parse(JSON.stringify(b));f.id=id;f.t={dot:[]};f.pvM=b.pv;f.agi=2;f.name=b.n+(ids.length>1?" "+(i+1):"");
   if(b.parts){f.p={};for(const k in b.parts)f.p[k]={n:b.parts[k][0],hp:b.parts[k][1],max:b.parts[k][1]};}return f;});
  const roll=u=>(d20()+(u.at?u.at.agi:2))*100+(u.at?u.at.agi:2);
  const st=Cb.st={party,foes,log:["Combate iniciado!"],turn:1,done,plan:{},over:null};
  st.order=party.slice().sort((a,b)=>roll(b)-roll(a));st.forder=foes.slice().sort((a,b)=>roll(b)-roll(a));
  st.log.push("Iniciativa (1d20+Agilidade): "+st.order.map(u=>u.name).join(", ")+" agem antes dos inimigos.");},
 L(m){Cb.st.log.push(m);},
 alive:u=>u.pv>0,
 foesAlive(){return Cb.st.foes.filter(f=>f.pv>0);},
 /* Alvos selecionáveis (partes de chefes incluídas). */
 targets(){const o=[];Cb.foesAlive().forEach(f=>{if(f.p){for(const k in f.p)if(f.p[k].hp>0)o.push({f,k,l:f.name+" — "+f.p[k].n+" ("+f.p[k].hp+")"});}else o.push({f,k:null,l:f.name+" ("+f.pv+"/"+f.pvM+")"});});return o;},
 allies(){return Cb.st.party.filter(u=>u.pv>0&&!u.summon);},
 canPay(u,s){const c=s.c;if(!c)return u.pv>(s.p||0);if(s.p&&u.pv<=s.p)return false;return u[c[0]]>=c[1];},
 /* Ações disponíveis para um personagem: {v,l,tg:'foe'|'ally'|'none',ok} */
 opts(u){const o=[{v:"atk",l:"Atacar",tg:"foe"},{v:"def",l:"Defender (+8 proteção)",tg:"none"},{v:"dod",l:"Esquivar",tg:"none"}];
  u.sk.forEach(id=>{const s=E.sk(u,id);const tg=["heal","absorb","cure"].includes(s.k)||(s.k==="guard"&&s.tg==="ally")?"ally":["atk","multi","mag","mark","scan","rand"].includes(s.k)&&!(s.k==="mag"&&!s.d&&!s.root&&!s.dt&&!s.sh&&!s.wk)?"foe":"none";
   o.push({v:"s:"+id,l:s.n+(s.c?" ("+s.c[1]+" "+{ef:"Esf",mp:"Mana"}[s.c[0]]+")":" (−"+s.p+" PV)"),tg,ok:Cb.canPay(u,s)});});
  const inv=E.S().inv;Object.keys(inv).forEach(id=>{const it=R.Items[id];if(it.t==="c"&&(it.e.pv||it.e.mp||it.e.ef))o.push({v:"i:"+id,l:it.n+" ×"+inv[id],tg:"ally"});});
  if(u===E.S().ch&&!Cb.st.foes.some(f=>f.boss))o.push({v:"flee",l:"Fugir ("+Cb.fleeChance()+"%)",tg:"none"});
  return o;},
 fleeChance(){const u=E.S().ch;return Math.max(5,Math.min(90,C.FLEE_BASE+C.FLEE_AGI*u.at.agi-5*Cb.foesAlive().length));},
 /* Dano em inimigo (ou parte). pen = proteção ignorada. */
 hitFoe(f,k,raw,pen,src){const pr=Math.max(0,f.pr-(f.t.shred?f.t.shred[0]:0)-(pen||0));let d=Math.max(1,raw-pr);
  if(k&&f.p[k]){d=Math.min(d,f.p[k].hp);f.p[k].hp-=d;f.pv=Math.max(0,f.pv-d);Cb.L(src+" causa "+d+" em "+f.name+" ("+f.p[k].n+").");if(f.p[k].hp<=0)Cb.L("★ "+f.p[k].n+" destruído(a)!");}
  else{f.pv=Math.max(0,f.pv-d);Cb.L(src+" causa "+d+" em "+f.name+".");}
  if(f.pv<=0)Cb.L("☠ "+f.name+" caiu.");return d;},
 /* Ataque com arma: d20 + atributo vs Defesa; 20 crítico (dobra), 1 falha crítica. */
 attack(u,tg,bonus){if(!tg||tg.f.pv<=0){tg=Cb.targets()[0];if(!tg)return false;}
  if(u.summon){Cb.hitFoe(tg.f,tg.k,u.d,0,u.name);return true;}
  const w=R.Items[u.eq.w],st=u.at[w.s],r=d20(),pen=(u.sa<=0?-2:0)+(u.fome>=1&&u.fome<25?C.HUNGER.hungryAtk:0);
  if(r===1){Cb.L(u.name+" tem uma falha crítica e perde o equilíbrio!");return false;}
  if(r!==20&&r+st+pen<tg.f.df){Cb.L(u.name+" erra ("+(r+st+pen)+" vs Defesa "+tg.f.df+").");return false;}
  let d=ri(w.d[0],w.d[1])+Math.floor(st/2)+(bonus||0)+(tg.f.t.mark?tg.f.t.mark[0]:0);if(r===20){d*=2;Cb.L("Acerto crítico!");}
  Cb.hitFoe(tg.f,tg.k,d,0,u.name);return true;},
 skill(u,s,tg,ally){const f=tg&&tg.f,t=u.t,L=Cb.L;
  if(s.c)u[s.c[0]]-=s.c[1];if(s.p)u.pv-=s.p;
  const k=s.k;L(u.name+" usa "+s.n+".");
  if(k==="atk"){if(Cb.attack(u,tg,s.b)){const x=Cb.st.foes.includes(tg.f)?tg.f:null;if(x&&x.pv>0){if(s.sh)x.t.shred=s.sh.slice();if(s.bl)x.t.dot.push({d:s.bl[0],t:s.bl[1]});}}}
  else if(k==="multi"){for(let i=0;i<s.n;i++)if(Cb.foesAlive().length)Cb.attack(u,tg&&tg.f.pv>0?tg:Cb.targets()[0],s.b);}
  else if(k==="mag"){if(!tg||tg.f.pv<=0)tg=Cb.targets()[0];if(!tg)return;const x=tg.f;
   if(s.d){let d=s.d;if(t.nb&&t.nb.n>0){d+=t.nb.b;t.nb.n--;}Cb.hitFoe(x,tg.k,d,s.pr||0,u.name);}
   if(x.pv>0){if(s.root){x.t.root=s.root;L(x.name+" fica preso.");}if(s.sh)x.t.shred=s.sh.slice();if(s.wk)x.t.weak=s.wk.slice();if(s.dt)x.t.dot.push({d:s.dt[0],t:s.dt[1]});}
   if(s.dr){u.pv=Math.min(u.pvM,u.pv+s.dr);L(u.name+" recupera "+s.dr+" PV.");}}
  else if(k==="heal"){const a=ally||u;a.pv=Math.min(a.pvM,a.pv+s.h);L(a.name+" recupera "+s.h+" PV.");}
  else if(k==="guard"){const g=s.tg==="party"?Cb.allies():[s.tg==="ally"&&ally?ally:u];g.forEach(a=>{a.t.g=s.r;a.t.gt=s.t;});}
  else if(k==="esf"){u.ef=Math.min(u.efM,u.ef+s.v);L(u.name+" recupera "+s.v+" Esforço.");}
  else if(k==="pact"){u.mp=Math.min(u.mpM,u.mp+s.m);L(u.name+" sacrifica "+s.p+" PV e recupera "+s.m+" Mana.");}
  else if(k==="nb"){t.nb={b:s.b,n:s.n};L("A próxima magia causará +"+s.b+" de dano.");}
  else if(k==="dotAll"){Cb.foesAlive().forEach(x=>x.t.dot.push({d:s.d,t:s.t}));}
  else if(k==="taunt"){t.taunt=s.t;L("Os inimigos voltam a atenção para "+u.name+".");}
  else if(k==="summon"){Cb.st.party.push({name:"Servo Reanimado",summon:1,pv:s.hp,pvM:s.hp,d:s.d,t:{dot:[]},at:{agi:1},eq:null,cond:{}});}
  else if(k==="mark"){if(f)f.t.mark=[s.b,s.t];}
  else if(k==="ret"){t.ret=s.d;t.rt=s.t;}
  else if(k==="dodge"){t.dodge=1;}
  else if(k==="absorb"){(ally||u).t.abs=s.a;}
  else if(k==="regen"){t.rg=s.h;t.rgt=s.t;}
  else if(k==="cure"){const a=ally||u,c=a.cond.veneno?"veneno":a.cond.febre?"febre":null;if(c){delete a.cond[c];L(a.name+" é purificado de "+c+".");}else L("Nada a purificar.");}
  else if(k==="scan"&&f){L(f.name+": PV ~"+f.pv+", Proteção "+f.pr+", Defesa "+f.df+(f.p?" | Partes: "+Object.values(f.p).map(p=>p.n+" "+p.hp).join(", "):"")+(f.st?" | pode causar "+f.st:"")+".");}
  else if(k==="rand"){const x=ri(1,3),up=s.up?3:0;if(x===1&&f){Cb.hitFoe(f,tg.k,12+up,0,u.name);}else if(x===2){u.pv=Math.min(u.pvM,u.pv+10+up);L(u.name+" se cura.");}else if(f){f.t.shred=[6+up,2];L("A proteção de "+f.name+" é corroída.");}}},
 /* Executa a ação planejada de um personagem. */
 act(u,p){const L=Cb.L,tgs=Cb.targets(),allies=Cb.allies();
  if(u.summon){Cb.attack(u,tgs[ri(0,tgs.length-1)]);return;}
  const tg=tgs[Math.min(p.t|0,tgs.length-1)],al=allies[Math.min(p.t|0,allies.length-1)];
  if(p.a==="atk")Cb.attack(u,tg);
  else if(p.a==="def"){u.t.def=1;L(u.name+" se defende.");}
  else if(p.a==="dod"){u.t.dod=1;L(u.name+" se prepara para esquivar.");}
  else if(p.a==="flee"){if(ri(1,100)<=Cb.fleeChance()){Cb.st.over="flee";L("Você escapa!");}else L("A fuga falha!");}
  else if(p.a.startsWith("i:"))L(E.useItem(al||u,p.a.slice(2)));
  else{const s=E.sk(u,p.a.slice(2));if(!Cb.canPay(u,s)){L(u.name+" não tem recursos para "+s.n+".");return;}Cb.skill(u,s,tg,al);}},
 /* Ação de um inimigo. */
 foeAct(f){const L=Cb.L,st=Cb.st;if(f.pv<=0)return;
  if(f.t.root>0){L(f.name+" está preso e perde a ação.");return;}
  let n=1,pen=0;if(f.p){n=(f.p.bd.hp>0)+(f.p.be.hp>0);if(!n){n=1;pen=3;}}
  for(let i=0;i<n;i++){const al=st.party.filter(u=>u.pv>0);if(!al.length)return;
   const w=[];al.forEach(u=>{for(let j=0;j<(u.t.taunt>0?5:1);j++)w.push(u);});const t=w[ri(0,w.length-1)];
   const r=d20()+C.ENEMY_ATK;
   if(t.t.dodge){t.t.dodge=0;L(t.name+" esquiva instintivamente de "+f.name+".");continue;}
   if(t.t.dod&&d20()+t.at.agi>=r){L(t.name+" esquiva o ataque de "+f.name+".");continue;}
   if(r<10+t.at.agi){L(f.name+" erra "+t.name+".");continue;}
   let d=ri(f.d[0],f.d[1])-pen-(f.t.weak?f.t.weak[0]:0);if(f.p&&f.p.pe.hp>0&&Math.random()<.3){d+=4;L(f.name+" investe!");}
   if(r-C.ENEMY_ATK===20){d*=2;L("Golpe crítico!");}
   const red=E.armor(t)+(t.t.g||0)+(t.t.def?8:0);d=Math.max(1,d-red);
   if(t.t.abs){const a=Math.min(t.t.abs,d);d-=a;t.t.abs=0;L("Proteção absorve "+a+".");}
   t.pv-=d;L(f.name+" causa "+d+" em "+t.name+".");
   if(f.p&&f.p.cab.hp>0&&!t.summon){t.sa=Math.max(0,t.sa-2);L("O gemido da cabeça abala a sanidade de "+t.name+" (−2).");}
   if(f.st&&!t.summon&&Math.random()<.3&&!t.cond[f.st]){t.cond[f.st]=1;L(t.name+" contraiu "+f.st+"!");}
   if(t.t.ret&&f.pv>0){Cb.hitFoe(f,null,t.t.ret,99,t.name+" (retaliação)");}
   if(t.pv<=0)L("☠ "+t.name+" caiu.");}},
 /* Um turno completo: personagens, inimigos, efeitos de duração. */
 round(){const st=Cb.st,L=Cb.L;L("— Turno "+st.turn+" —");
  st.order.forEach(u=>{if(st.over||u.pv<=0||!Cb.foesAlive().length)return;Cb.act(u,st.plan[st.party.indexOf(u)]||{a:"atk",t:0});});
  st.party.filter(u=>u.summon&&u.pv>0&&!st.order.includes(u)).forEach(u=>{if(Cb.foesAlive().length)Cb.act(u,{});});
  if(!st.over&&Cb.foesAlive().length)st.forder.forEach(f=>Cb.foeAct(f));
  st.foes.forEach(f=>{if(f.pv<=0)return;f.t.dot=f.t.dot.filter(x=>{f.pv=Math.max(0,f.pv-x.d);L(f.name+" sofre "+x.d+" de dano contínuo.");x.t--;return x.t>0;});
   if(f.pv<=0)L("☠ "+f.name+" caiu.");["root"].forEach(k=>{if(f.t[k]>0)f.t[k]--;});["shred","weak","mark"].forEach(k=>{if(f.t[k]&&--f.t[k][1]<=0)delete f.t[k];});});
  st.party.forEach(u=>{const t=u.t;if(u.pv<=0)return;if(t.rgt>0){u.pv=Math.min(u.pvM,u.pv+t.rg);t.rgt--;L(u.name+" regenera "+t.rg+" PV.");}
   if(t.gt>0&&--t.gt<=0)t.g=0;if(t.rt>0&&--t.rt<=0)t.ret=0;if(t.taunt>0)t.taunt--;t.def=0;t.dod=0;});
  st.plan={};st.turn++;
  if(!Cb.foesAlive().length)st.over="win";else if(st.party[0].pv<=0)st.over="dead";},
 /* Encerra: XP, saque, limpeza de efeitos temporários. */
 finish(){const st=Cb.st,S=E.S(),res=st.over;let msg=[];
  st.party=st.party.filter(u=>!u.summon);E.members().forEach(u=>{delete u.t;});
  if(res==="win"){let xp=0;st.foes.forEach(f=>{xp+=f.xp;(f.loot||[]).forEach(l=>{if(Math.random()<l[1]){E.give(l[0]);msg.push("Saque: "+R.Items[l[0]].n);}});});
   msg.push("+"+xp+" XP");msg=msg.concat(E.xp(xp));}
  const r=E.reap();r.dead.forEach(u=>msg.push("☠ "+u.name+" morreu permanentemente."));
  S.stats.combats++;
  Cb.st=null;return {res:r.hero?"dead":res,msg};}
};
})();
