/* Regras de personagem: criação, equipamentos, itens, fome, condições, descanso e níveis. */
(function(){
const R=RPG,C=R.Config,ri=(a,b)=>a+Math.floor(Math.random()*(b-a+1));
const E=R.E={ri,d20:()=>ri(1,20),S:()=>R.Save.current,
 mk(cid,name,o){const c=R.Classes[cid],r=c.r;
  return Object.assign({name,cls:cid,lvl:1,xp:0,at:Object.assign({},c.a),pv:r[0],pvM:r[0],mp:r[1],mpM:r[1],ef:r[2],efM:r[2],sa:r[3],saM:r[3],fome:80,sk:[c.sk[0].id],ev:[],eq:{w:c.st,a:"roupa",s:null},cond:{},pend:null},o||{});},
 sk(u,id){const b=R.SK[id];return u.ev.includes(id)?Object.assign({},b,b.e):b;},
 armor(u){const I=R.Items;return u.eq?(I[u.eq.a].p||0)+(u.eq.s?I[u.eq.s].p:0):0;},
 hs(f){return f>=75?"Saciado":f>=50?"Alimentado":f>=25?"Com fome":f>=1?"Faminto":"Inanição";},
 give(id,n){const i=E.S().inv;i[id]=(i[id]||0)+(n||1);},
 take(id){const i=E.S().inv;if(!i[id])return false;if(--i[id]<=0)delete i[id];return true;},
 members(){const S=E.S();return [S.ch].concat(S.party);},
 /* Equipar: respeita compatibilidade da classe. */
 can(u,id){const c=R.Classes[u.cls],t=R.Items[id].t;return t==="w"?c.w.includes(id):t==="a"?id==="roupa"||c.ar.includes(id):t==="s"?!!c.sh:false;},
 equip(u,id){const it=R.Items[id],slot={w:"w",a:"a",s:"s"}[it.t];
  if(!slot||!E.can(u,id))return "Sua classe não pode usar "+it.n+".";
  if(!E.take(id))return "Item indisponível.";
  const old=u.eq[slot];if(old&&old!=="roupa")E.give(old);u.eq[slot]=id;return it.n+" equipado.";},
 unequip(u,slot){const old=u.eq[slot];if(!old||old==="roupa")return;E.give(old);u.eq[slot]=slot==="a"?"roupa":null;},
 /* Consumíveis e alimentos. */
 useItem(u,id){const it=R.Items[id],e=it.e;if(!e)return "Não pode ser usado.";if(!E.take(id))return "Acabou.";let m=[];
  if(e.pv){u.pv=Math.min(u.pvM,u.pv+e.pv);m.push("+"+e.pv+" PV");}
  if(e.ef){u.ef=Math.min(u.efM,u.ef+e.ef);m.push("+"+e.ef+" Esforço");}
  if(e.mp){u.mp=Math.min(u.mpM,u.mp+e.mp);m.push("+"+e.mp+" Mana");}
  if(e.fome){u.fome=Math.min(100,u.fome+e.fome);m.push("+"+e.fome+" fome");if(it.risk&&Math.random()<.4){u.cond.febre=u.cond.febre||1;m.push("adoeceu (febre)");}}
  if(e.cure){if(u.cond[e.cure]){delete u.cond[e.cure];m.push("tratou "+e.cure);}else m.push("nada a tratar");}
  return u.name+": "+m.join(", ")+".";},
 /* Passagem de cena: fome, veneno, febre. Retorna avisos. */
 tick(){const S=E.S(),out=[];
  E.members().forEach(u=>{u.fome=Math.max(0,u.fome-C.HUNGER_MOVE);
   if(u.fome===0){u.pv-=C.HUNGER.starvePV;out.push(u.name+" sofre de inanição.");}
   if(u.cond.veneno){u.pv-=2;out.push(u.name+" sofre com o veneno.");}
   if(u.cond.febre){u.pv-=u.cond.febre;u.cond.t=(u.cond.t||0)+1;if(u.cond.t%3===0&&u.cond.febre<3){u.cond.febre++;out.push("A febre de "+u.name+" piora.");}}});
  return out;},
 /* Remove companheiros mortos (morte permanente). Retorna true se o protagonista morreu. */
 reap(){const S=E.S(),dead=S.party.filter(u=>u.pv<=0);
  dead.forEach(u=>{S.flags["morto_"+u.id]=1;});S.party=S.party.filter(u=>u.pv>0);return {dead,hero:S.ch.pv<=0};},
 /* Descanso: recupera recursos e parte da sanidade; pode gerar evento. */
 rest(k){const S=E.S(),L=k==="long",f=L?C.REST.long:C.REST.short,Rs=C.REST;
  E.members().forEach(u=>{["pv","mp","ef"].forEach(a=>u[a]=Math.min(u[a+"M"],u[a]+Math.ceil(u[a+"M"]*f)));
   u.sa=Math.min(u.saM,u.sa+(L?Rs.saL:Rs.saS));u.fome=Math.max(0,u.fome-(L?Rs.hL:Rs.hS));});
  const r={msg:"Você descansa ("+(L?"longo":"curto")+"). Recursos e parte da sanidade foram recuperados."};
  if(Math.random()<Rs.ev){const x=ri(1,3);
   if(x===1){r.msg+=" Algo se move no escuro: uma emboscada!";r.fight=["lobo"];}
   else if(x===2){E.give("erva");r.msg+=" Ao amanhecer você encontra uma erva medicinal perto do acampamento.";}
   else{r.msg+=" Você sonha com um sino afundando em lama escura. Ao acordar, ainda ouve as badaladas: três.";E.S().flags.sonho=1;}}
  return r;},
 /* XP e níveis (máx. 4 na v1.0). Pontos por nível vêm de Config.POINTS_PER_LEVEL. */
 xp(n){const u=E.S().ch,m=[];u.xp+=n;
  while(u.lvl<C.MAX_LEVEL_V1&&u.xp>=C.XP[u.lvl+1]){u.lvl++;u.pend=u.pend||{pts:0};u.pend.pts+=C.POINTS_PER_LEVEL;
   if(u.lvl===3)u.pend.skill=true;if(u.lvl===4)u.pend.evo=true;m.push("Nível "+u.lvl+"!");}
  return m;},
 /* Aplica a distribuição de pontos e os ganhos de recursos (base da classe + atributo). */
 levelUp(alloc,skill,evo){const u=E.S().ch,g=R.Classes[u.cls].g;
  for(const a in alloc)u.at[a]+=alloc[a];
  const lv=u.lvlApplied||1;
  for(let l=lv+1;l<=u.lvl;l++){u.pvM+=g[0]+u.at.vig;u.pv+=g[0]+u.at.vig;u.mpM+=g[1]+u.at.int;u.mp+=g[1]+u.at.int;
   u.efM+=g[2]+u.at.pre;u.ef+=g[2]+u.at.pre;u.saM+=g[3]+u.at.sab;u.sa+=g[3]+u.at.sab;}
  u.lvlApplied=u.lvl;
  if(skill)u.sk.push(skill);if(evo)u.ev.push(evo);u.pend=null;}
};
})();
