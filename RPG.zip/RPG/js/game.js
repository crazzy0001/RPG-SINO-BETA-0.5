/* Estado global da partida, navegação entre telas, contagem de tempo e autosave. */
(function () {
  const C = RPG.Config;
  const Game = {
    screen: "title",
    history: [],
    settings: { autosave: true },

    show(name, push) {
      if (push !== false && this.screen !== name) this.history.push(this.screen);
      document.querySelectorAll(".screen").forEach(s => s.hidden = s.dataset.screen !== name);
      this.screen = name;
      window.scrollTo(0, 0);
      document.dispatchEvent(new CustomEvent("screenchange", { detail: name }));
    },
    back() { this.show(this.history.pop() || "title", false); },

    loadSettings() {
      try { Object.assign(this.settings, JSON.parse(localStorage.getItem(C.SETTINGS_KEY)) || {}); } catch (e) {}
    },
    saveSettings() {
      try { localStorage.setItem(C.SETTINGS_KEY, JSON.stringify(this.settings)); } catch (e) {}
    },

    startNew() {
      const s = RPG.Save.create();
      if (!s) { RPG.UI.toast("Não foi possível gravar o save. Verifique o armazenamento do navegador."); return; }
      this.history = [];
      this.show("hub", false);
    },
    continueGame() {
      if (!RPG.Save.load()) { RPG.UI.toast("O save está ausente ou corrompido."); return; }
      this.history = [];
      this.show("hub", false);
    },
    abandon() {
      RPG.Save.remove();
      this.history = [];
      this.show("title", false);
    },

    /** Conta tempo de jogo (só com a aba visível) e executa autosave periódico. */
    startClock() {
      setInterval(() => {
        if (document.hidden || !RPG.Save.current) return;
        RPG.Save.current.playtimeSec += 1;
      }, 1000);
      setInterval(() => { if (this.settings.autosave) RPG.Save.save(); }, C.AUTOSAVE_MS);
      // Salva ao ocultar/sair: cobre fechar o navegador ou trocar de app no celular.
      const flush = () => RPG.Save.save();
      document.addEventListener("visibilitychange", () => { if (document.hidden) flush(); });
      window.addEventListener("pagehide", flush);
    }
  };
  RPG.Game = Game;
})();
