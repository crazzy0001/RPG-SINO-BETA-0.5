/* Salvamento local (localStorage). Todas as operações tratam falhas de armazenamento. */
(function () {
  const C = RPG.Config;
  /* Se o navegador bloquear o localStorage (ex.: arquivo aberto direto no celular), usa memória: o jogo funciona, mas não persiste. */
  const store = (function(){try{const k='__t';store.setItem(k,'1');store.removeItem(k);return localStorage;}catch(e){const m={};return {mem:true,getItem:k=>k in m?m[k]:null,setItem:(k,v)=>{m[k]=String(v);},removeItem:k=>{delete m[k];}};}})();
  RPG.StoreBlocked = !!store.mem;
  const Save = {
    current: null,
    lastError: null,

    exists() {
      try { return store.getItem(C.SAVE_KEY) !== null; } catch (e) { return false; }
    },
    /** Cria um save novo e o grava. `extra` sobrescreve campos iniciais. */
    create(extra) {
      this.current = Object.assign({
        saveVersion: C.SAVE_VERSION,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        playtimeSec: 0,
        stage: "criacao",
        character: null,
        party: [],
        inventory: [],
        quests: [],
        flags: {},
        region: null
      }, extra || {});
      return this.save() ? this.current : null;
    },
    save() {
      if (!this.current) return false;
      try {
        this.current.updatedAt = Date.now();
        store.setItem(C.SAVE_KEY, JSON.stringify(this.current));
        this.lastError = null;
        return true;
      } catch (e) { this.lastError = e; return false; }
    },
    load() {
      try {
        const raw = store.getItem(C.SAVE_KEY);
        if (!raw) return null;
        const data = JSON.parse(raw);
        if (!data || typeof data !== "object") throw new Error("save inválido");
        this.current = data;
        return data;
      } catch (e) { this.lastError = e; return null; }
    },
    /** Aplica uma alteração ao save atual e grava em seguida. */
    update(fn) {
      if (!this.current) return false;
      fn(this.current);
      return this.save();
    },
    remove() {
      try { store.removeItem(C.SAVE_KEY); } catch (e) {}
      this.current = null;
    },
    /** Resumo legível para a tela inicial. */
    summary() {
      try {
        const d = JSON.parse(store.getItem(C.SAVE_KEY));
        return d ? { updatedAt: d.updatedAt, playtimeSec: d.playtimeSec, stage: d.stage, character: d.character } : null;
      } catch (e) { return null; }
    },
    formatTime(sec) {
      const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
      return h > 0 ? h + " h " + m + " min" : m + " min";
    }
  };
  RPG.Save = Save;
})();
