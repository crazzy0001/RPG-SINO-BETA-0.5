/* Ponto de entrada: liga a interface às ações do jogo. */
(function(){
const R=RPG,$=id=>document.getElementById(id),G=R.Game,U=R.UI,E=R.E;
function refreshTitle(){$("btn-continue").disabled=!R.Save.exists();const s=R.Save.summary();
 $("continue-info").textContent=s?"Última sessão: "+new Date(s.updatedAt).toLocaleString("pt-BR")+" · "+R.Save.formatTime(s.playtimeSec)+" de jogo":"Nenhuma jornada salva.";}
document.addEventListener("screenchange",e=>{if(e.detail==="title")refreshTitle();if(e.detail==="settings")$("opt-autosave").checked=G.settings.autosave;});
G.startNew=function(){if(!R.Save.create()){U.toast("Não foi possível iniciar a jornada.");return;}G.history=[];U.create();if(R.StoreBlocked)U.toast("Aviso: este navegador bloqueia o salvamento. O progresso se perde ao fechar. Abra o jogo por um servidor ou link https.");};
G.continueGame=function(){const S=R.Save.load();if(!S){U.toast("Save ausente ou corrompido.");return;}G.history=[];
 if(!S.ch)U.create();else if(R.Story.scenes[S.scene].end){R.Save.remove();G.show("title",false);}else U.play();};
const rt=()=>{const m=$("menu-body");U.menu();};
document.addEventListener("click",e=>{
 const d=e.target.closest("button,[data-action]");if(!d||d.disabled)return;const D=d.dataset,S=R.Save.current;
 if(D.action){const a=D.action;
  if(a==="new")R.Save.exists()?G.show("confirm-new"):G.startNew();
  else if(a==="confirm-new")G.startNew();else if(a==="continue")G.continueGame();
  else if(a==="settings")G.show("settings");
  else if(a==="back"){G.back();if(G.screen==="play")U.play();}
  else if(a==="cr-back")U.crClass();
  else if(a==="begin")U.play();
  else if(a==="menu")U.menu();
  else if(a==="level"){U.lv=null;U.level();}
  else if(a==="lv-ok"){const v=U.lv;E.levelUp(v.a,v.s,v.e);U.lv=null;R.Save.save();G.history=[];U.play();}
  else if(a==="turn")U.cbTurn();
  else if(a==="pz-ok")U.pzTry();else if(a==="pz-hint")U.pzHint();
  else if(a==="end-new"){R.Save.remove();G.history=[];G.startNew();}
  else if(a==="to-title"){R.Save.save();G.history=[];G.show("title",false);}
  else if(a==="delete"){if(confirm("Apagar a jornada salva? Isso não pode ser desfeito.")){G.abandon();U.toast("Save apagado.");}}
  return;}
 if(D.cls)U.crDetail(D.cls);
 else if(D.origin)U.crStart(D.origin);
 else if(D.ch!==undefined)U.pick(U._cs[+D.ch]);
 else if(D.tab)U.menu(D.tab);
 else if(D.use){const u=E.members()[U.tgt||0];U.toast(E.useItem(u,D.use));R.Save.save();U.menu();}
 else if(D.eq){U.toast(E.equip(S.ch,D.eq));R.Save.save();U.menu();}
 else if(D.un){E.unequip(S.ch,D.un);R.Save.save();U.menu();}
 else if(D.craft!==undefined){const r=R.Recipes[+D.craft];r[0].forEach(i=>E.take(i));E.give(r[1]);U.toast("Criado: "+R.Items[r[1]].n);R.Save.save();U.menu();}
 else if(D.lv){const s=D.lv[0],a=D.lv.slice(1),v=U.lv;v.a[a]=Math.max(0,(v.a[a]||0)+(s==="+"?1:-1));U.lvDraw();}
 else if(D.lvs){U.lv.s=D.lvs;U.lvDraw();}else if(D.lve){U.lv.e=D.lve;U.lvDraw();}
});
document.addEventListener("change",e=>{const t=e.target,D=t.dataset;
 if(t.id==="opt-autosave"){G.settings.autosave=t.checked;G.saveSettings();}
 else if(t.id==="tgt"){U._tg=U.tgt=+t.value;}
 else if(D.act!==undefined){U.pl[D.act]={a:t.value,t:0};U.cbDraw();}
 else if(D.tg!==undefined){U.pl[D.tg].t=+t.value;}});
G.loadSettings();G.startClock();G.show("title",false);
if("serviceWorker" in navigator&&location.protocol.startsWith("http"))navigator.serviceWorker.register("service-worker.js").catch(()=>{});
})();
