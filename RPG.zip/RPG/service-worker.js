/* Cache-first para funcionar offline. Aumente CACHE ao alterar a lista de arquivos. */
const CACHE = "rpg-sino-v2";
const FILES = ["./","index.html","manifest.json","icons/icon.svg",
  "css/style.css","css/interface.css","css/combat.css",
  "data/config.js","data/classes.js","data/items.js","data/story.js","js/save.js","js/game.js","js/engine.js","js/combat.js","js/ui.js","js/main.js"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES))); self.skipWaiting(); });
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
